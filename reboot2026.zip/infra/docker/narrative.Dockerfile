FROM python:3.12-slim

WORKDIR /app
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1

COPY llm-narrative-server/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY llm-narrative-server/ .

EXPOSE 8001
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8001"]
